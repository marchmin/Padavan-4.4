Third-party packaging
=====

Builds packages for various embedded devices and appliances and platforms
