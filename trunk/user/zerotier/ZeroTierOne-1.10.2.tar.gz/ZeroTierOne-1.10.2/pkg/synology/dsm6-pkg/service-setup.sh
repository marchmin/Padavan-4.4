
service_postinst()
{
	exit 0
}

service_postuninst()
{
	exit 0
}

service_postupgrade()
{
	exit 0
}

service_preinst()
{
	exit 0
}

service_preuninst()
{
	exit 0
}

service_preupgrade()
{
	exit 0
}
