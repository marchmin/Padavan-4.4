#!/bin/sh

rm -rf /var/lib/zerotier-one/
